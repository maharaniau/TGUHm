plot.CNAseg <-
function(CNA.seg){
  chr.border <- c(CNA.seg$chr[1], which(diff(CNA.seg$chr)!=0))
  chr.num <- unique(CNA.seg$chr)
  chr.name <- vector()
  for(i in 1:length(chr.num)){
    chr.name[i] = paste("chr",chr.num[i]) 
  }
  plot(CNA.seg$x, col="grey", pch=20, xaxt="n", ylab = "Copy Number Ratio", xlab = paste("Genomic location"),ylim=c(min(CNA.seg$x),7))
  for(i in 2:length(chr.border)){
    abline(v = chr.border[i], lty=3)
  }
  
  chr.mid <- chr.border + (diff(c(chr.border,length(CNA.seg$x))/2))
  axis(side=1, at=chr.mid, labels = chr.name)
  lines(CNA.seg$segmented, lwd=2)
}
