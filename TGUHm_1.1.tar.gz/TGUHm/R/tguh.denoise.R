tguh.denoise <-
function (tguh.decomp.obj, lambda, minseglen = 1, bal = 1/20) 
{
  n <- tguh.decomp.obj$n
  protected <- rep(0, n)
  for (i in 1:(n - 1)) {
    if (!protected[tguh.decomp.obj$decomp.hist[1, 1, i]] & 
        !protected[tguh.decomp.obj$decomp.hist[1, 2, i]]) 
        tguh.decomp.obj$decomp.hist[3, 1, i] <- tguh.decomp.obj$decomp.hist[3, 1, i] * ((abs(tguh.decomp.obj$decomp.hist[3, 1, i]) > lambda) & 
                                                                                          (round(tguh.decomp.obj$decomp.hist[4, 1, i]) >= minseglen) &
                                                                                          (round(tguh.decomp.obj$decomp.hist[4, 2, i]) >= minseglen) & 
                                                                                          (tguh.decomp.obj$decomp.hist[2, 1, i]^2 > bal) & 
                                                                                          (tguh.decomp.obj$decomp.hist[2, 2, i]^2 > bal))
    if (abs(tguh.decomp.obj$decomp.hist[3, 1, i]) > 0) 
      protected[tguh.decomp.obj$decomp.hist[1, 1, i]] <- 1
  }
  return(tguh.decomp.obj)
}
