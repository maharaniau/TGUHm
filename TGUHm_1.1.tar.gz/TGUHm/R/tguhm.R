tguhm <-
function(x, chr, c=2){
  x.na <- which(is.na(x)==TRUE)
  x <- na.omit(x)
  if(length(x.na)>0){
  chr <- chr[-x.na]}
  chr.num <- unique(chr)
  chr.n <- length(chr.num)
  segmented <- vector()
  
  for(j in 1:chr.n){
    obj <- x[chr==chr.num[j]]
    n= length(obj)
    tguh.decomp.obj = tguh.decomp(obj)
    lambda = mad(diff(obj)/sqrt(2))* sqrt(2 *(1+0.01)* log(length(obj)))
    thresh = tguh.denoise(tguh.decomp.obj, minseglen = c, bal=0, lambda= lambda)
    for (i in 1:(n - 1)) {
      thresh$decomp.hist[3, 1, i] <- thresh$decomp.hist[3, 1, i] * ((round(thresh$decomp.hist[4, 1, i]) >= c)& 
                                                                      (round(thresh$decomp.hist[4, 2, i]) >= c))
    }
    
    cpt.loc = vector()
    count =1
    for (i in 1:(n-1)){
      if(thresh$decomp.hist[3,1,i]!= 0){
        cpt.loc[count] = thresh$decomp.hist[1,2,i]-1
        count = count+1
      }
    }
    cpt.loc = sort(cpt.loc)
    cpt.loc[length(cpt.loc)+1]=n
    segmented.t= vector()
    cpt.str = 1
    for (i in 1:length(cpt.loc)) {
      segmented.t[cpt.str:cpt.loc[i]] = mean(obj[cpt.str:cpt.loc[i]])
      cpt.str = cpt.loc[i]+1
    }
    segmented <- c(segmented, segmented.t)
  }
  CNA.seg <- list(x=x, segmented=segmented, chr=chr)
  class(CNA.seg) <- "CNAsegmented"
  return(CNA.seg)
}
